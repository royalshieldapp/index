# Lightning Background (Live)

This project demonstrates a live WebGL lightning shader rendered as a fullscreen background using React and Vite.  
You can use it as a hero section or embed it into a site to provide an eye‑catching animated backdrop.

## Development

```sh
npm install
npm run dev
```

The development server will start at http://localhost:5173/.

## Build & Preview

To build the project for production and preview the build locally:

```sh
npm run build
npm run preview
```

## Deploying to GitHub Pages

The `vite.config.js` file sets the `base` option to `/index/`, which ensures assets resolve correctly when hosted on GitHub Pages under the `index` subpath (e.g., `https://USERNAME.github.io/index/`).  
After building the project (`npm run build`), copy the contents of the `dist` folder into your `index` repository.  
Commit and push these files to publish the live lightning background.