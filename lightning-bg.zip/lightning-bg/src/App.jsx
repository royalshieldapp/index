import Lightning from "./Lightning";
import "./App.css";

/**
 * The main application component.
 *
 * Renders the lightning shader as a full-screen background with an overlay.
 */
export default function App() {
  return (
    <div className="wrap" aria-hidden="true">
      {/* The lightning component renders a fullscreen WebGL canvas */}
      <Lightning hue={220} xOffset={0} speed={1} intensity={1} size={1} />
      {/* A semi-transparent overlay darkens the background to improve text contrast */}
      <div className="overlay" />
    </div>
  );
}