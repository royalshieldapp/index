import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Vite configuration for the lightning background project.
// The `base` option is set to `/index/` because the GitHub Pages project
// is served from the `index` subpath of the user's GitHub Pages site.
export default defineConfig({
  base: "/index/",
  plugins: [react()],
});